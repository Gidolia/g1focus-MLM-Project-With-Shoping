<?php
error_reporting(1);
mysql_connect("localhost","Gidolia","Gidolia50750")or die("database not connected");
mysql_select_db("G1focus")or die("database not selected");
session_start();
if (empty($_SESSION[shop_id])){ header("location:login.php");}

?>