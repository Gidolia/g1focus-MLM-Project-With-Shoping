<?php
session_start();
			
			
		unset($_SESSION['carttrr']);
			
			
		header("location:bill.php");

?>