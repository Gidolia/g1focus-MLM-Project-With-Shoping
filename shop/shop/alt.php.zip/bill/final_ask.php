<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#apDiv1 {
	position:absolute;
	left:26px;
	top:24px;
	width:219px;
	height:128px;
	z-index:1;
}
#apDiv2 {
	position:absolute;
	left:787px;
	top:40px;
	width:249px;
	height:168px;
	z-index:2;
}
#apDiv3 {
	position:absolute;
	left:33px;
	top:276px;
	width:1003px;
	height:53px;
	z-index:3;
}
</style>
</head>

<body>
<div id="apDiv1"><h2>G1mart Pvt Ltd</h2><br /></div>
<div id="apDiv2"></div>
<div id="apDiv3"></div>
</body>
</html>