<?php include "../config.php";
if(isset($_POST[submit]))
{
	
	$que="select max(bill_id) as max from bill";
     $r=mysql_query($que) or die("query not performed");
if($r)
  {
  $row=mysql_fetch_array($r);  
  $bill_id=$row['max'];

  $bill_id=$bill_id+1;
  
  }
if($_POST[d_id]<81464){$status='t';}
else{$status='c';}
$o_date=date("Y/m/d");
foreach($_SESSION['carttrr'] as $idt=>$val)
{
	
	$query="select * from product where p_id='$val[p_id]'";
	$res=mysql_query($query) or die("Can't Execute Query...");
	$row=mysql_fetch_assoc($res);	
	$total=$val[qty]*$row[p_selling_price];	
	$total_bv_p=$val[qty]*$row[p_bv];
	
	$total_price=$total+$total_price;
	$total_bv_pm=$total_bv_pm+$total_bv_p;
}

$ins="INSERT INTO bill(bill_id,d_id,o_date,name,addreass,mobile,mobile2,pincode,city,state,addreasstype,price,bv,status,paid,shop_id) VALUES('$bill_id','$_POST[d_id]','$o_date','$name','$addreass','$mobile','$mobile2','$pincode','$city','$state','$addreasstype','".$total_price."','".$total_bv_pm."','$status','cash','$_SESSION[shop_id]')";
mysql_query($ins) or die("Try again query not executed");

foreach($_SESSION['carttrr'] as $id=>$x)
{

	$insert="INSERT INTO bill_detail(bill_id,p_id,qty) VALUES('".$bill_id."','".$x[p_id]."','".$x[qty]."')";
	mysql_query($insert) or die("Try again value not inserted");
	$qe="select * from shop_product where shop_id='$_SESSION[shop_id]' and p_id='$x[p_id]'";
$rees=mysql_query($qe);
$ce=mysql_fetch_assoc($rees);
$nqty=$ce[qty]-$x[qty];
if ($nqty==0){mysql_query("delete from shop_product where p_id=$x[p_id]") or die ("not deleted");}
else{
	mysql_query("update shop_product set qty=".$nqty." where p_id=".$x[p_id]." and shop_id=".$_SESSION[shop_id]);}
	
  } unset($_SESSION[carttrr]);
  header("location:bill_print.php?bill_id=$bill_id");}
  elseif(isset($_POST[joinsubmit])){	$que="select max(bill_id) as max from bill";
     $r=mysql_query($que) or die("query not performed");
if($r)
  {
  $row=mysql_fetch_array($r);  
  $bill_id=$row['max'];

  $bill_id=$bill_id+1;
  
  }
if($_POST[d_id]<81464){$status='t';}
else{$status='c';}
$o_date=date("Y/m/d");
foreach($_SESSION['carttrr'] as $idt=>$val)
{
	
	$query="select * from product where p_id='$val[p_id]'";
	$res=mysql_query($query) or die("Can't Execute Query...");
	$row=mysql_fetch_assoc($res);	
	$total=$val[qty]*$row[p_selling_price];	
	$total_bv_p=$val[qty]*$row[p_bv];
	
	$total_price=$total+$total_price;
	$total_bv_pm=$total_bv_pm+$total_bv_p;
}

$ins="INSERT INTO bill(bill_id,d_id,o_date,name,addreass,mobile,mobile2,pincode,city,state,addreasstype,price,bv,status,paid,shop_id) VALUES('$bill_id','$_POST[d_id]','$o_date','$name','$addreass','$mobile','$mobile2','$pincode','$city','$state','$addreasstype','".$total_price."','".$total_bv_pm."','$status','cash','$_SESSION[shop_id]')";
mysql_query($ins) or die("Try again query not executed");

foreach($_SESSION['carttrr'] as $id=>$x)
{

	$insert="INSERT INTO bill_detail(bill_id,p_id,qty) VALUES('".$bill_id."','".$x[p_id]."','".$x[qty]."')";
	mysql_query($insert) or die("Try again value not inserted");
	$qe="select * from shop_product where shop_id='$_SESSION[shop_id]' and p_id='$x[p_id]'";
$rees=mysql_query($qe);
$ce=mysql_fetch_assoc($rees);
$nqty=$ce[qty]-$x[qty];
if ($nqty==0){mysql_query("delete from shop_product where p_id=$x[p_id]") or die ("not deleted");}
else{
	mysql_query("update shop_product set qty=".$nqty." where p_id=".$x[p_id]." and shop_id=".$_SESSION[shop_id]);}
	
  } unset($_SESSION[carttrr]);
   $ins="INSERT INTO distributor(d_id,sponsor_no,proposer_no,d_name,father_name,nominee_name,d_dob,nominee_dob,house_addreass,state,district,tehsil,post,city,pincode,mobile,mobile2,email,id_proof,addreass_proof,password,joining_date,kyc,new) VALUES('$_POST[d_id]','$_SESSION[s_no]','$_SESSION[p_no]','$_SESSION[d_name]','$_SESSION[father]','$_SESSION[nominee_name]','$_SESSION[dd_date]','$_SESSION[nominee_dob]','$_SESSION[d_add]','$_SESSION[state]','$_SESSION[district]','$_SESSION[tehsil]','$_SESSION[post]','$_SESSION[city]','$_SESSION[pincode]','$_SESSION[mobile]','$_SESSION[mobile2]','$_SESSION[email]','$_SESSION[idproof]','$_SESSION[addproof]','$_SESSION[passwordn]','$o_date','n','y')";
					mysql_query($ins)or die ("values not inserted");

  header("location:bill_print.php?bill_id=$bill_id");}
  else{echo "something went wrong please try again";}
?>