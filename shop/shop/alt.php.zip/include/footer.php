<footer class="site-footer">
          <div class="text-center">
              2014 - Gidolia
              
          </div>
      </footer>